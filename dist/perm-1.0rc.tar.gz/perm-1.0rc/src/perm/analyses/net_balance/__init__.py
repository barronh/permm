__all__ = ['IRRTable', 'NetTableMaker', 'PhyTableMaker', 'PtbMaker', 'SumTableMaker']

import IRRTable
import NetTableMaker
import PhyTableMaker
import PtbMaker
import SumTableMaker

def net_balance(args, options):
    from perm.analyses.net_balance.PhyTableMaker import PhyTable
    from perm.analyses.net_balance.SumTableMaker import SumTable
    from perm.analyses.net_balance.NetTableMaker import NetTables
    from perm.analyses.net_balance.PhyTableMaker import PhyTables
    from perm.analyses.net_balance.PhyTableMaker import VOCTable
    from perm.analyses.net_balance.PtbMaker import PtbTable
    from perm.analyses.net_balance.IRRTable import IRRTable
    from perm import getmech
    from ...netcdf import NetCDFFile
    
    get_prepared_mech = getmech.get_prepared_mech
    get_pure_mech = getmech.get_pure_mech
    try:
        mech = get_prepared_mech(options.mechanism)
    except:
        mech = get_pure_mech(options.mechanism)
    
    mrg_data_path = args[0]
    mrg_file = NetCDFFile(mrg_data_path,'rs')
    mech.set_mrg(mrg_file)

    if options.output is None:
        net_data_path = '.'.join(mrg_data_path.split('.')[:-1])+'.net.'
    else:
        net_data_path = options.output+'.'
    print >> file(net_data_path+'sum','wb'), SumTable(mech)
    print >> file(net_data_path+'net','wb'), NetTables(mech)
    print >> file(net_data_path+'phy','wb'), PhyTables(mech)
    print >> file(net_data_path+'voc','wb'), VOCTable(mech)
    print >> file(net_data_path+'ptb','wb'), PtbTable(mech)
    mech = get_pure_mech(options.mechanism)

    mech.set_mrg(mrg_file)
    
    print >> file(net_data_path+'irr','wb'), IRRTable(mech)